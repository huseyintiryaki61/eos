<? require_once 'init.php'; 
session_start();
ob_start();
if(isset($_POST["ayar"])){
	$d=degerler($_POST);
	$ekle=DB::baglan()->guncelle('admin',3,array(
	'komisyon' => $_POST["komisyon"],
	'saat' => $_POST["saat"]
	));
	if($ekle){
					$response['status']="success";
$response['title']="Başarılı";
$response['message']="Ayarlar değişti";
echo json_encode($response);
	}else{
	$response['status']="error";
$response['title']="Başarısız";
$response['message']="Ayarlar değişmedi";
echo json_encode($response);
	}		

	
}
if(isset($_POST["login"])){
	$ad=$_POST["admin_kadi"];
	$sifre=$_POST["admin_sifre"];
	$varad=DB::baglan()->getir("admin",array('admin_kadi','=',$ad))->sayac();
	if($varad<1){
		$response['status']="error";
$response['title']="Hata";
$response['message']="Kullanici bulunamadi";
echo json_encode($response);
	}else{
		$k=DB::baglan()->getir("admin",array('admin_kadi','=',$ad))->ilk();
		if($sifre != $k->admin_sifre){
					$response['status']="error";
$response['title']="Hata";
$response['message']="Yanlış şifre girildi";
echo json_encode($response);
		}else{
			$_SESSION["giris"]=$k->Id;
$response['status']="success";
$response['title']="Giriş Başarılı";
$response['message']="Lütfen bekleyiniz";
echo json_encode($response);
		}
	}
}
if(isset($_POST["fatura_sonodeme"])){
$tarih=date("H:i:s");
if(!isset($_SESSION["fatura"])){
	$urun["no"]=$_POST["fatura_no"];
	$urun["kar"]=$_POST["fatura_kar"];
	$urun["sonodeme"]=$_POST["fatura_sonodeme"];
	$urun["ad"]=$_POST["fatura_ad"];
	$urun["tutar"]=$_POST["fatura_tutar"];
	$urun["zaman"]=date("d/m/Y H:i:s");
	$urun["sira"]=1;
	$sepet[] = $urun;
	$_SESSION["fatura"][1]=$sepet;
	$_SESSION["sayi"]=1;
}
else{
	$sayi=$_SESSION["sayi"]+1;
$urun["no"]=$_POST["fatura_no"];
	$urun["kar"]=$_POST["fatura_kar"];
	$urun["sonodeme"]=$_POST["fatura_sonodeme"];
	$urun["ad"]=$_POST["fatura_ad"];
	$urun["tutar"]=$_POST["fatura_tutar"];
	$urun["zaman"]=date("d/m/Y H:i:s");
	$urun["sira"]=count($_SESSION["fatura"])+1;
	$sepet[] = $urun;
	$_SESSION["fatura"][$sayi]=$sepet;
$_SESSION["sayi"]++;
}
	

		$response['status']="success";
$response['title']="Sepete Eklendi";
$response['message']="Fatura sepete eklendi";
echo json_encode($response);
		
}
if(isset($_POST["hepsi"])){
	unset($_SESSION["fatura"]);
	unset($_SESSION["sayi"]);
$response['status']="success";
$response['title']="İşlem Başarılı";
$response['message']="Sepete Temizlendi";
echo json_encode($response);
}
if(isset($_POST["sil"])){
	$s=explode(",",$_POST["sil"]);
	foreach($s as $b){
		unset($_SESSION["fatura"][$b]);
	}
$response['status']="success";
$response['title']="Silindi";
$response['message']="Seçililer Silindi";
echo json_encode($response);
}
if(isset($_POST["kayit"])){
$ys=json_decode(json_encode($_SESSION["fatura"]), True);
$s=json_decode(json_encode($ys), False);
$ayar=DB::baglan()->getir("admin",array("Id",'=',$_SESSION["giris"]))->ilk();
$say=0;
$hata="";
$hsay=0;
foreach($s as $d){
	$toplam=($d[0]->tutar+$ayar->komisyon);
	$fekle=DB::baglan()->ekle('faturaler',array(
	'fatura_ad'=>$d[0]->ad,
	'fatura_no'=>$d[0]->no,
	'fatura_tutar'=>$toplam,
	'fatura_sonodeme'=>$d[0]->sonodeme,
	'fatura_kar'=>$ayar->komisyon
	));
	if($fekle){
		$r=$d[0]->sira;
		$say++;
		unset($_SESSION["fatura"][$r]);
	}else{
		$hata.=$d[0]->sira; 
		$hsay++;
	}
}
if($hsay>0){
		$response['status']="error";
$response['title']="İşlem Başarısız";
$response['message']=$hsay." Fatura Ödenemedi";
echo json_encode($response);
}else{
		$response['status']="success";
$response['title']="İşlem Başarılı";
$response['message']=$say." Fatura Ödendi ".$r;
$response['sayi']=$say;
echo json_encode($response);
}

}
if(isset($_POST["kasa"])){
	$a=$_POST["kasa"];
	$d=$_POST["deger"];
	if(!empty($_POST["deger2"])){
		$deger2=$_POST["deger2"];
	}
	if($a==1){
		$ara=DB::baglan()->ilanara("select count(*) AS adet,sum(fatura_tutar) AS tutar,sum(fatura_kar) as kar  from faturaler  WHERE fatura_zaman like '%".$d."%'");
				$response['status']="success";
$response['adet']=$ara[0]->adet;
$response['tutar']=$ara[0]->tutar;
$response['kar']=$ara[0]->kar;
echo json_encode($response);
	}else if($a==2){
		$date = date('d-m-Y', strtotime("+1 day", strtotime($deger2)));
		$ara=DB::baglan()->ilanara("SELECT count(*) as adet, sum(fatura_tutar) as tutar,sum(fatura_kar) as kar
FROM `faturaler`
WHERE (fatura_zaman BETWEEN '".$d."'  AND '".$deger2."' )");
$response['status']="success";
$response['adet']=$ara[0]->adet;
$response['tutar']=$ara[0]->tutar;
$response['kar']=$ara[0]->kar;
echo json_encode($response);
	}

}
?>