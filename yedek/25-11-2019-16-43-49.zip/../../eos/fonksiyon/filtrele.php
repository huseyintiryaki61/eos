<?php 
function filtrele($string){
	return htmlentities($string,ENT_QUOTES, 'UTF-8');
}
function degerler($pst){
	$hepsi=array();
	foreach($pst as $post => $value ){
		if(!empty($value)){
			if(is_array($value)){
			$value=implode($value,",");
			}
		$hepsi[$post]=$value;
		}	
	}
return $hepsi;
	
}

?>