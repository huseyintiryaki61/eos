<? require_once 'header.php'; ?>
<h1 class="text-center text-warning">Destek</h1>
<div class="col-md-12">
<h5 class="mt-4">Sistem arızaları ile ilgili durumlarda lütfen bizimle iletişime geçiniz.</h5>
<div class="col-md-12">
<div class="row">
<div class="col-md-4 mt-4">
<i title="+905012041461" class="fas fa-mobile fa-8x ml-5"></i>
<p class="bold h4" >+905012041461</p>
</div>
<div class="col-md-4 mt-4">
<i title="huseyin.tiryaki61@gmail.com" class="fas fa-envelope fa-8x ml-5"></i>
<p class="bold h4" >huseyin.tiryaki61@gmail.com</p>
</div>
<div class="col-md-4 mt-4"></div>
</div>

</div>
</div>
<? require_once 'footer.php'; ?>